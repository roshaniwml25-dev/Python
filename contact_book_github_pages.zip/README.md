# Contact Book
A simple browser-based contact manager with add, view, search, edit and delete features.

## GitHub Pages deployment
1. Upload `index.html`, `style.css`, and `script.js` to the repository root.
2. Open **Settings → Pages**.
3. Under **Build and deployment**, select **Deploy from a branch**.
4. Select branch **main** and folder **/(root)**, then Save.
5. Wait for GitHub Pages to publish your site.

Contacts are saved in this browser's localStorage. They are not shared between devices or browsers.
